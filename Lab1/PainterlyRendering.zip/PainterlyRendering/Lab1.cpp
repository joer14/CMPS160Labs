/**
* CMPS 160L (Fall 2011)
* Lab1.cpp: Painterly Rendering
* Joe Rowley jrowley@ucsc.edu 
*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ppm_canvas.h"
#include <GLUT/glut.h>
#define PI 3.14159265
// Global variables: add window dimensions, previous x-y mouse coordinates, brush
//                   technique state, and any globals needed for added features.
canvas_t canvas;
int brush = 1;
float brushSize = 10;
int erase = false;
int prevX, prevY = 0;

void callback_display() {
   // Leave this empty.
}

void callback_mouse(int button, int state, int x, int y) {
    // Add code here to update last x-y mouse coordinates whenever mouse is clicked.
    if (brush != 2) return;
    pixel_t pixel = PIXEL(canvas, x, y);
    int r = RED(pixel);
    int g = GREEN(pixel);
    int b = BLUE(pixel);
    glColor3ub(r, g, b);
    glBegin( GL_QUADS );
    glVertex3f(x,y,0);
    glVertex3f(x, y+brushSize*2, 0);
    glVertex3f(x+brushSize*2, y+brushSize*2,0);
    glVertex3f(x+brushSize*2,y,0);
    glEnd();
    glFlush();
}

void paintCircle(int x, int y)
{   printf("paintCircle\n");
    glBegin( GL_TRIANGLE_FAN );
    pixel_t pixel = PIXEL(canvas, x, y);
    int r = RED(pixel);
    int g = GREEN(pixel);
    int b = BLUE(pixel);
    glColor3ub(r, g, b);
    glVertex2f(x, y);
    for( int n = 0; n <= 10; ++n ) {
        float const t = 2*M_PI*(float)n/10;
        glVertex2f(x + sin(t)*brushSize, y + cos(t)*brushSize);
    }
    glEnd();
    glFlush();
    return;
}

void paintCont(int x, int y){
    printf("paintCont\n");
    if ((prevX != 0) && (prevY != 0)){
        pixel_t pixel = PIXEL(canvas, x, y);
        int r = RED(pixel);
        int g = GREEN(pixel);
        int b = BLUE(pixel);
        glColor3ub(r, g, b);
        glBegin( GL_QUADS );
        glVertex3f(prevX, prevY, 0);
        glVertex3f(prevX, prevY+brushSize*2, 0);
        glVertex3f(x, y+brushSize*2, 0);
        glVertex3f(x,y,0);
        glEnd();
        glFlush();
        prevX = x;
        prevY = y;
        
    }
    else{
        printf("nope");
        prevX = x;
        prevY = y;
        glVertex3f(x, y, 0);
        glVertex3f(x, y+20, 0);
        glVertex3f(x+20, y+20, 0);
        glVertex3f(x+20,y,0);
    }
    return;
}


/*
 
 Figuring out orientation
 
 need to figure out the angle theta between old point and new point, so draw a right angle, then tangent=opp/adj
 so arctan(y-py/x-px)= angle theta
 
 -.x,y
 - }
 .-  }
 
 px,py
 
 
 theta=atan2(y-py,x-px)
 
 */

void paintCust(int x, int y){
    if ((prevX ==0)|| (prevY ==0)) {
        prevX = x;
        prevY = y;
        return;
    }
    pixel_t pixel = PIXEL(canvas, x, y);
    int r = RED(pixel);
    int g = GREEN(pixel);
    int b = BLUE(pixel);
    float theta;
    theta = atan2(y-prevY,x-prevX);
    float dtheta = theta * 180 / PI;
    glPushMatrix();
    glLoadIdentity();
    glTranslatef(x,y,0);
    glRotatef(dtheta,0.0f,0.0f,1.0f);
    glRotatef(180,1.0f,1.0f,0.0f);
    glBegin(GL_QUADS);
    glColor3ub(r, g, b);
    float br= brushSize/5;
    glVertex2f(0,0);
    glVertex2f(0,10*br);
    glVertex2f(10*br,10*br);
    glVertex2f(10*br,0);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3ub(r, g, b);
    glVertex2f(-5*br,10*br);
    glVertex2f(5*br,20*br);
    glVertex2f(15*br,10*br);
    glEnd();
    glPopMatrix();
    glFlush();
    prevX = x;
    prevY = y;
//    printf("angle theta: %f\n",dtheta);
//    printf("brushsize: %f\n",brushSize);
//    printf("other x: %f, y: %f\n",Otherx, Othery);
    return;
}

void callback_motion(int x, int y) {
//   pixel_t pixel;
   // Add code to extract corresponding pixel color from source image and draw it
   // with an interesting brush shape. Don't forget to glFlush() to force drawing, and
   // to update the previous x-y mouse coordinates!
    if (x<1) return;
    if (y<1) return;
    if (x>canvas.width) return;
    if (y>canvas.height) return;
    //pixel_t pixel = PIXEL(canvas, x, y);
    //printf("x: %d, y: %d \n",x,y);
    // for erasing
    if (erase){
        glColor3ub(0, 0, 0);
        glBegin( GL_TRIANGLES );
        glVertex3f(x, y, 0);
        glVertex3f(x, y+20, 0);
        glVertex3f(x-20, y, 0);
        glEnd();
        glFlush();
    }
    // for non eraser modes - use a switch or call other brush methods
    else{
        switch(brush) {
            case 1:
                paintCircle(x,y);
                break;
            case 2:
                paintCont(x,y);
                break;
            case 3:
                paintCust(x,y);
                break;
            
                // Add extra cases to alter brush size, clear the canvas, etc.
        }
        
    };
    
}

void changeBrush(){
    if (brush == 3) {
        brush = 1;
    }
    else brush = brush+1;
    printf("brush: %d\n",brush);
    prevX = prevY = 0;
    return;
}

void resizeBrush(bool change){
    if (change) {
        brushSize = brushSize + 1;

    }
    else {
        if (brushSize <2) return;
        brushSize = brushSize-1;


    }
    printf("brush size: %f\n",brushSize);
    return;
}
void clearCanvas(){
    glColor3ub(0, 0, 0);
    glBegin( GL_QUADS );
    glVertex3f(0, 0, 0);
    glVertex3f(0, canvas.height, 0);
    glVertex3f(canvas.width, canvas.height, 0);
    glVertex3f(canvas.width, 0, 0);
    glEnd();
    glFlush();
    return;
}

void eraser(){
    if (erase == true) erase = false;
    else erase = true;
    //code to erase;
}
//Provide keystroke or menu to clear the canvas
//Provide key or menu to change brush size
//Provide key or menu to change brush shape (at least three shapes including circle and thick line)
//q to quit
void callback_keyboard(unsigned char key, int x, int y) {
   switch(key) {
      case 'q':
         exit(0);
      case 'b':
         changeBrush();
           break;
      case 'c':
           clearCanvas();
      case 'j':
           resizeBrush(true);
           break;
      case 'k':
           resizeBrush(false);
           break;
      case 'e':
           eraser();
           break;
      break;
      // Add extra cases to alter brush size, clear the canvas, etc.
   }
}

void callback_reshape(int w, int h) {
   glViewport(0, 0, w, h); /* tell GL what size the window should be */
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluOrtho2D(0, w, h, 0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glClear(GL_COLOR_BUFFER_BIT);
   glFlush();
}


int main(int argc, char* argv[]) {
   glutInit(&argc, argv); /* initialize GLUT and let it grab arguments */
   if (argc == 2) {
      if (ppmLoadCanvas(argv[1], &canvas) < 0) {
         printf("Failed to open file: %s\n", argv[1]);
         return -1;
      }
      else printf("Loaded file: %s\n", argv[1]);
   }
   else {
      printf("Usage: %s source.ppm\n", argv[0]);
      return -1;
   }
   
   // Print out some useful example information...
//   printf("Width: %d\n", canvas.width);
//   printf("Height: %d\n", canvas.height);
   int x = rand() % canvas.width;
   int y = rand() % canvas.height;
   pixel_t pixel = PIXEL(canvas, x, y);
   int r = RED(pixel);
   int g = GREEN(pixel);
   int b = BLUE(pixel);
//   printf("Pixel (%d, %d) has R=%d G=%d B=%d\n", x, y, r, g, b);
    printf("Move the mouse to paint the picture. Use j and j to change brush size, b to change brush, e to turn on and off the eraser, and c to clear the canvas. \n");
   
   // Add code to print a menu with your added user options.
   
   glutInitWindowSize(canvas.width, canvas.height);
   glutInitDisplayMode(GLUT_RGBA);
   glutCreateWindow(argv[0]);
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glClearColor(0, 0, 0, 0);
   
   // Register Callbacks:
   glutDisplayFunc(callback_display);
   glutMouseFunc(callback_mouse);
   glutMotionFunc(callback_motion);
   glutKeyboardFunc(callback_keyboard);
   glutReshapeFunc(callback_reshape);
   
   // Hand control off to GLUT!
   glutMainLoop();
   
   return 0;
}
